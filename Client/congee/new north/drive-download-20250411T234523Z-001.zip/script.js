// Get input elements
const nameInput = document.getElementById("nameInput");
const emailInput = document.getElementById("emailInput");
const passwordInput = document.getElementById("passwordInput");

// Function to handle input changes
function handleInput(event) {
  const input = event.target;
  const value = input.value;

  // Store the value in a variable (you can use this later for form submission)
  input.dataset.value = value;

  // Basic validation
  if (input.type === "email") {
    const isValidEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    input.style.borderColor =
      isValidEmail || value === "" ? "rgba(0, 0, 0, 0.5)" : "red";
  }

  if (input.type === "password") {
    const isValidPassword = value.length >= 6;
    input.style.borderColor =
      isValidPassword || value === "" ? "rgba(0, 0, 0, 0.5)" : "red";
  }
}

// Add event listeners to inputs
nameInput.addEventListener("input", handleInput);
emailInput.addEventListener("input", handleInput);
passwordInput.addEventListener("input", handleInput);

// Form submission handler
document
  .querySelector(".signup-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    const formData = {
      name: nameInput.value,
      email: emailInput.value,
      password: passwordInput.value,
    };

    console.log("Form submitted with data:", formData);
    // Here you can add your API call or further processing
  });
