// Initialize state and functions
const state = {
  selectedCategory: "Popular",
  searchQuery: "",
  menuItems: [
    {
      id: 1,
      name: "China Chicken",
      description:
        "Succulent, tender and juicy half chicken marinated with oriental spices deep-fried. An original best seller since the birth of NORTH PARK!",
      price: 428.0,
      image: "https://c.animaapp.com/YbRZsaiC/img/rectangle-3@2x.png",
      quantity: 0,
    },
    {
      id: 2,
      name: "Imported Broccoli Flower in Oyster Sauce",
      description:
        "Crisp broccoli florets lavishly poured with premium oyster sauce. Recommended for vegetarian customers. High in flavonoids, low in calorie!",
      price: 228.0,
      image: "https://c.animaapp.com/YbRZsaiC/img/rectangle-4@2x.png",
      quantity: 0,
    },
  ],
  categories: [
    "Popular",
    "Noodles",
    "Congee",
    "Soups",
    "Rice Meals",
    "Hotpot",
    "Dimsum",
    "Dessert",
    "Drinks",
  ],
  orderItems: [],
};

// Filter menu items based on search query
function getFilteredMenuItems() {
  return state.menuItems.filter((item) => {
    const searchLower = state.searchQuery.toLowerCase();
    return item.name.toLowerCase().includes(searchLower);
  });
}

// Render category buttons
function renderCategories() {
  const categoriesNav = document.getElementById("categories");
  if (!categoriesNav) return;

  categoriesNav.innerHTML = state.categories
    .map(
      (category) => `
      <button
        class="category-button ${state.selectedCategory === category ? "active" : ""}"
        onclick="handleCategoryClick('${category}')"
      >
        ${category}
      </button>
    `,
    )
    .join("");
}

// Highlight search terms in text
function highlightSearch(text) {
  if (!state.searchQuery) return text;
  const regex = new RegExp(`(${state.searchQuery})`, "gi");
  return text.replace(regex, "<mark>$1</mark>");
}

// Render menu items
function renderMenuItems() {
  const menuGrid = document.getElementById("menuItems");
  if (!menuGrid) return;

  const filteredItems = getFilteredMenuItems();

  if (filteredItems.length === 0) {
    menuGrid.innerHTML = `
      <div class="no-results">
        <p>No items found matching "${state.searchQuery}"</p>
        <button onclick="clearSearch()" class="clear-search-button">Clear Search</button>
      </div>
    `;
    return;
  }

  menuGrid.innerHTML = filteredItems
    .map(
      (item) => `
      <article class="menu-item">
        <img
          src="${item.image}"
          alt="${item.name}"
          class="menu-item-image"
        />
        <div class="menu-item-content">
          <h3 class="menu-item-title">${highlightSearch(item.name)}</h3>
          <p class="menu-item-description">${item.description}</p>
          <div class="menu-item-footer">
            <span class="menu-item-price">
              <span>&#8369;</span>${item.price.toFixed(2)}
            </span>
            <div class="quantity-controls">
              <button
                class="quantity-button decrease-button"
                onclick="updateQuantity(${item.id}, -1)"
              >-</button>
              <span>${item.quantity}</span>
              <button
                class="quantity-button increase-button"
                onclick="updateQuantity(${item.id}, 1)"
              >+</button>
            </div>
          </div>
        </div>
      </article>
    `,
    )
    .join("");
}

// Render order items
function renderOrderItems() {
  const orderItemsContainer = document.getElementById("orderItems");
  const totalAmountElement = document.getElementById("totalAmount");

  if (!orderItemsContainer || !totalAmountElement) return;

  const total = state.orderItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0,
  );

  orderItemsContainer.innerHTML = state.orderItems
    .map(
      (item) => `
      <div class="order-item">
        <div class="order-item-details">
          <div class="order-item-name">${item.name}</div>
          <div class="order-item-price">
            <span>&#8369;</span>${item.price.toFixed(2)} x ${item.quantity}
          </div>
        </div>
        <div class="order-item-total">
          <span>&#8369;</span>${(item.price * item.quantity).toFixed(2)}
        </div>
      </div>
    `,
    )
    .join("");

  totalAmountElement.innerHTML = `&#8369;${total.toFixed(2)}`;
}

// Initialize search input handler
document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.querySelector(".search-input");
  if (!searchInput) return;

  let searchTimeout;
  searchInput.addEventListener("input", (e) => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      state.searchQuery = e.target.value;
      renderMenuItems();
    }, 300);
  });

  // Load saved table number if exists
  const savedTableNumber = localStorage.getItem("tableNumber");
  if (savedTableNumber) {
    const tableInput = document.getElementById("tableNumber");
    if (tableInput) {
      tableInput.value = savedTableNumber;
    }
  }
});

// Global functions for HTML event handlers
window.clearSearch = function () {
  state.searchQuery = "";
  const searchInput = document.querySelector(".search-input");
  if (searchInput) searchInput.value = "";
  renderMenuItems();
};

window.toggleOrderForm = function () {
  const orderSection = document.getElementById("orderSection");
  const overlay = document.getElementById("overlay");

  if (orderSection && overlay) {
    orderSection.classList.toggle("hidden");
    overlay.classList.toggle("visible");

    if (!orderSection.classList.contains("hidden")) {
      renderOrderItems();
    }
  }
};

window.handleCategoryClick = function (category) {
  state.selectedCategory = category;
  renderCategories();
};

window.updateQuantity = function (id, increment) {
  state.menuItems = state.menuItems.map((item) => {
    if (item.id === id) {
      const newQuantity = Math.max(0, item.quantity + increment);

      if (increment > 0) {
        const existingOrderItem = state.orderItems.find(
          (orderItem) => orderItem.id === id,
        );
        if (existingOrderItem) {
          existingOrderItem.quantity = newQuantity;
        } else {
          state.orderItems.push({
            id: item.id,
            name: item.name,
            price: item.price,
            quantity: 1,
          });
        }
      } else if (increment < 0) {
        const existingOrderItem = state.orderItems.find(
          (orderItem) => orderItem.id === id,
        );
        if (existingOrderItem) {
          if (newQuantity === 0) {
            state.orderItems = state.orderItems.filter(
              (orderItem) => orderItem.id !== id,
            );
          } else {
            existingOrderItem.quantity = newQuantity;
          }
        }
      }

      return {
        ...item,
        quantity: newQuantity,
      };
    }
    return item;
  });

  renderMenuItems();
  renderOrderItems();
};

window.handleCheckout = function () {
  if (state.orderItems.length === 0) {
    alert("Please add items to your order first.");
    return;
  }

  const tableInput = document.getElementById("tableNumber");
  const tableNumber = tableInput.value.trim();

  if (!tableNumber) {
    alert("Please enter your table number.");
    tableInput.focus();
    return;
  }

  // Save table number for convenience
  localStorage.setItem("tableNumber", tableNumber);

  const total = state.orderItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0,
  );

  // Format order summary
  const orderSummary = state.orderItems
    .map(
      (item) =>
        `${item.name} x${item.quantity} - ₱${(item.price * item.quantity).toFixed(2)}`,
    )
    .join("\n");

  alert(
    `Order Summary:\n` +
      `Table Number: ${tableNumber}\n` +
      `------------------\n` +
      `${orderSummary}\n` +
      `------------------\n` +
      `Total Amount: ₱${total.toFixed(2)}\n\n` +
      `Thank you for your order!`,
  );

  // Reset order
  state.orderItems = [];
  state.menuItems = state.menuItems.map((item) => ({ ...item, quantity: 0 }));

  renderMenuItems();
  renderOrderItems();

  // Close order panel
  toggleOrderForm();
};

// Initial render
document.addEventListener("DOMContentLoaded", () => {
  renderCategories();
  renderMenuItems();
  renderOrderItems();
});
